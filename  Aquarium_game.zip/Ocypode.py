import Crab


class Ocypode(Crab.Crab):
    def __init__(self, name, age, x, y, directionH):
        pass

    def get_animal(self):
        pass
