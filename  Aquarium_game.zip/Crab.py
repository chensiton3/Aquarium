import Animal

MAX_CRAB_HEIGHT = 4
MAX_CRAB_WIDTH = 7


class Crab(Animal.Animal):
    def __init__(self, name, age, x, y, directionH):
        pass

    def __str__(self):
        pass

    def starvation(self):
        pass

    def die(self):
        pass
